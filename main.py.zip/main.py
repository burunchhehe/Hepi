import openai

# ✅ 형의 GPT API 키 여기 입력!
openai.api_key = "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"

# ✅ GPT에게 질문 보내기
response = openai.chat.completions.create(
    model="gpt-4",
    messages=[
        {"role": "system", "content": "너는 경매 전문가야."},
        {"role": "user", "content": "전세사기 어떻게 피하죠?"}
    ]
)

# ✅ GPT 응답 출력
print(response.choices[0].message.content)

from googleapiclient.discovery import build

# ✅ 유튜브 API 키 입력
API_KEY = "AIzaSyCEADGqC8oiYMJkMxx_IfW4-6F5MK6Rxb4"

# ✅ 유튜브 API 연결
youtube = build("youtube", "v3", developerKey=API_KEY)

# ✅ 유튜브 영상 검색 함수
def search_youtube(query, max_results=3):
    print("\n[유튜브 검색 결과]")
    search_response = youtube.search().list(
        q=query,
        type="video",
        part="id,snippet",
        maxResults=max_results
    ).execute()

    for item in search_response['items']:
        title = item['snippet']['title']
        video_id = item['id']['videoId']
        print(f"{title}\nhttps://www.youtube.com/watch?v={video_id}\n")

# ✅ 실행
search_youtube("전세사기")

import os
import requests

# 환경변수에서 봇 토큰과 챗 ID 가져오기
TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")

def send_telegram_message(text):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    data = {
        "chat_id": CHAT_ID,
        "text": text
    }
    response = requests.post(url, data=data)
    return response.json()

# 실행해보기
if __name__ == "__main__":
    send_telegram_message("✅ 헤피 서버가 Render에서 실행됐어요!")
